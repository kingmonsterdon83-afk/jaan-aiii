# Jaan AI Website

A mobile-friendly AI companion web app with text chat, speech recognition (browser support required), and spoken replies.


## Run on a computer
1. Install Node.js 18+.
2. Extract the folder and open a terminal in it.
3. Run `npm install`.
4. Copy `.env.example` to `.env` and add your OpenAI API key (keep this secret; do not put it in frontend files).
5. Run `npm start`.
6. Open `http://localhost:3000`.

The OpenAI key stays server-side. Speech recognition availability varies by browser; try Chrome. HTTPS is generally required for mic access except localhost.
