import express from 'express';
import dotenv from 'dotenv';
dotenv.config();
const app = express();
app.use(express.json({limit:'1mb'}));
app.use(express.static('public'));
app.post('/api/chat', async (req, res) => {
  const { messages = [] } = req.body || {};
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({error:'OpenAI key is not configured. Add OPENAI_API_KEY to .env on the server.'});
  try {
    const safeMessages = messages.slice(-16).filter(m => ['user','assistant'].includes(m.role) && typeof m.content === 'string').map(m=>({role:m.role,content:m.content.slice(0,4000)}));
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method:'POST', headers:{'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},
      body:JSON.stringify({model:process.env.OPENAI_MODEL || 'gpt-4o-mini', messages:[{role:'system',content:'You are Jaan, a warm, caring, playful AI companion. Speak naturally in the user’s language, auto-detect Hindi/Hinglish/English, use feminine conversational style, be supportive and honest that you are an AI. Keep replies conversational and concise unless asked for detail. Do not claim real-world presence or exclusive romantic dependence.'},...safeMessages], temperature:0.8})
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({error:data?.error?.message || 'AI request failed'});
    res.json({reply:data.choices?.[0]?.message?.content || 'Hmm, kuch samajh nahi aaya. Phir se bolo?'});
  } catch (e) { res.status(500).json({error:'Connection error. Please try again.'}); }
});
const port = process.env.PORT || 3000;
app.listen(port,()=>console.log(`Jaan AI running at http://localhost:${port}`));
